"""SQLite-backed persistent memory and conversation history."""

import json
import logging
import sqlite3
import threading
from datetime import datetime
from pathlib import Path

from atlas.config import settings

logger = logging.getLogger(__name__)

_local = threading.local()


def _get_conn() -> sqlite3.Connection:
    if not hasattr(_local, "conn"):
        db_path = Path(settings.memory_db_path)
        db_path.parent.mkdir(parents=True, exist_ok=True)
        _local.conn = sqlite3.connect(str(db_path))
        _local.conn.row_factory = sqlite3.Row
        _init_tables(_local.conn)
    return _local.conn


def _init_tables(conn: sqlite3.Connection) -> None:
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content TEXT NOT NULL,
            category TEXT DEFAULT 'fact',
            confidence REAL DEFAULT 0.8,
            embedding TEXT,
            created_at TEXT NOT NULL,
            last_accessed TEXT NOT NULL,
            access_count INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS conversation_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            session_id TEXT DEFAULT 'default'
        );

        CREATE INDEX IF NOT EXISTS idx_memories_category ON memories(category);
        CREATE INDEX IF NOT EXISTS idx_conv_session ON conversation_history(session_id);
        CREATE INDEX IF NOT EXISTS idx_conv_timestamp ON conversation_history(timestamp);
    """)
    conn.commit()


# --- Conversation History ---

def add_message(role: str, content: str, session_id: str = "default") -> None:
    conn = _get_conn()
    conn.execute(
        "INSERT INTO conversation_history (role, content, timestamp, session_id) VALUES (?, ?, ?, ?)",
        (role, content, datetime.utcnow().isoformat(), session_id),
    )
    conn.commit()


def get_history(session_id: str = "default", limit: int = 20) -> list[dict]:
    conn = _get_conn()
    rows = conn.execute(
        "SELECT role, content FROM conversation_history WHERE session_id = ? ORDER BY id DESC LIMIT ?",
        (session_id, limit),
    ).fetchall()
    return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]


def get_message_count(session_id: str = "default") -> int:
    conn = _get_conn()
    row = conn.execute(
        "SELECT COUNT(*) as cnt FROM conversation_history WHERE session_id = ?",
        (session_id,),
    ).fetchone()
    return row["cnt"]


def clear_history(session_id: str = "default") -> None:
    conn = _get_conn()
    conn.execute("DELETE FROM conversation_history WHERE session_id = ?", (session_id,))
    conn.commit()


# --- Memories ---

def save_memory(content: str, category: str = "fact", confidence: float = 0.8, embedding: list[float] | None = None) -> int:
    conn = _get_conn()
    now = datetime.utcnow().isoformat()
    emb_json = json.dumps(embedding) if embedding else None
    cursor = conn.execute(
        "INSERT INTO memories (content, category, confidence, embedding, created_at, last_accessed) VALUES (?, ?, ?, ?, ?, ?)",
        (content, category, confidence, emb_json, now, now),
    )
    conn.commit()
    return cursor.lastrowid


def get_all_memories() -> list[dict]:
    conn = _get_conn()
    rows = conn.execute("SELECT * FROM memories ORDER BY last_accessed DESC").fetchall()
    return [dict(r) for r in rows]


def get_memories_by_category(category: str) -> list[dict]:
    conn = _get_conn()
    rows = conn.execute("SELECT * FROM memories WHERE category = ? ORDER BY confidence DESC", (category,)).fetchall()
    return [dict(r) for r in rows]


def touch_memory(memory_id: int) -> None:
    conn = _get_conn()
    conn.execute(
        "UPDATE memories SET last_accessed = ?, access_count = access_count + 1 WHERE id = ?",
        (datetime.utcnow().isoformat(), memory_id),
    )
    conn.commit()


def delete_memory(memory_id: int) -> None:
    conn = _get_conn()
    conn.execute("DELETE FROM memories WHERE id = ?", (memory_id,))
    conn.commit()


def memory_exists(content: str) -> bool:
    conn = _get_conn()
    row = conn.execute("SELECT 1 FROM memories WHERE content = ? LIMIT 1", (content,)).fetchone()
    return row is not None
