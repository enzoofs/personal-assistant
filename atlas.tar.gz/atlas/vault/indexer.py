"""ChromaDB indexing and semantic search for the Obsidian vault."""

import hashlib
import logging
import re
from pathlib import Path

import chromadb
import frontmatter

from atlas.config import settings
from atlas.services.openai_client import _client as openai_client

logger = logging.getLogger(__name__)

_collection = None


def get_collection() -> chromadb.Collection:
    """Get or create the ChromaDB collection for vault notes."""
    global _collection
    if _collection is None:
        chroma_client = chromadb.PersistentClient(path=settings.chroma_db_path)
        _collection = chroma_client.get_or_create_collection(name="vault_notes")
    return _collection


def _file_hash(content: str) -> str:
    """Generate SHA256 hash of file content."""
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _get_embedding(text: str) -> list[float]:
    """Get embedding vector for text using OpenAI."""
    response = openai_client.embeddings.create(
        model="text-embedding-3-small",
        input=text,
    )
    return response.data[0].embedding


def index_vault() -> int:
    """Index all markdown files in the vault into ChromaDB.

    Uses content hash as ID for incremental updates.

    Returns:
        Number of documents indexed/updated.
    """
    vault_path = Path(settings.vault_path)
    if not vault_path.exists():
        logger.warning("Vault path does not exist: %s", vault_path)
        return 0

    collection = get_collection()
    count = 0

    for md_file in vault_path.rglob("*.md"):
        try:
            raw = md_file.read_text(encoding="utf-8")
            post = frontmatter.loads(raw)

            content = post.content.strip()
            if not content:
                continue

            doc_id = _file_hash(raw)
            relative_path = str(md_file.relative_to(vault_path))
            title = post.metadata.get("title", md_file.stem)

            embedding = _get_embedding(content[:8000])

            # Extract wikilinks and topics for metadata
            links = re.findall(r"\[\[([^\]|]+)(?:\|[^\]]+)?\]\]", content)
            topics = post.metadata.get("topics", [])

            collection.upsert(
                ids=[doc_id],
                documents=[content[:8000]],
                embeddings=[embedding],
                metadatas=[{
                    "path": relative_path,
                    "title": title,
                    "category": post.metadata.get("category", ""),
                    "links": ",".join(links) if links else "",
                    "topics": ",".join(topics) if isinstance(topics, list) else "",
                }],
            )
            count += 1
        except Exception:
            logger.exception("Failed to index %s", md_file)
            continue

    logger.info("Indexed %d documents in vault", count)
    return count


def search_vault(query: str, n_results: int = 5) -> list[dict]:
    """Search the vault using semantic similarity.

    Args:
        query: Search query text.
        n_results: Maximum number of results.

    Returns:
        List of dicts with keys: path, title, snippet.
    """
    try:
        collection = get_collection()
        if collection.count() == 0:
            return []

        embedding = _get_embedding(query)

        results = collection.query(
            query_embeddings=[embedding],
            n_results=min(n_results, collection.count()),
        )

        output = []
        for i, doc_id in enumerate(results["ids"][0]):
            metadata = results["metadatas"][0][i] if results["metadatas"][0] else {}
            document = results["documents"][0][i] if results["documents"][0] else ""
            output.append({
                "path": metadata.get("path", ""),
                "title": metadata.get("title", ""),
                "snippet": document[:300],
            })

        return output
    except Exception:
        logger.exception("Vault search failed")
        return []
