"""Vault statistics and analytics."""

import logging
import re
from collections import Counter
from pathlib import Path

import frontmatter

from atlas.config import settings

logger = logging.getLogger(__name__)


def get_vault_stats() -> dict:
    """Compute statistics about the Obsidian vault.

    Returns:
        Dict with vault analytics: total notes, links, orphans, top topics.
    """
    vault = Path(settings.vault_path)
    if not vault.exists():
        return {"total_notes": 0}

    total = 0
    total_links = 0
    topics_counter: Counter = Counter()
    linked_targets: set[str] = set()
    all_stems: set[str] = set()
    notes_today = 0
    today_str = __import__("datetime").datetime.now().strftime("%Y-%m-%d")

    for md_file in vault.rglob("*.md"):
        if md_file.name.startswith("."):
            continue
        total += 1
        all_stems.add(md_file.stem.lower())

        try:
            raw = md_file.read_text(encoding="utf-8")
            post = frontmatter.loads(raw)

            # Count wikilinks
            links = re.findall(r"\[\[([^\]|]+)(?:\|[^\]]+)?\]\]", post.content)
            total_links += len(links)
            for link in links:
                linked_targets.add(link.lower())

            # Count topics
            note_topics = post.metadata.get("topics", [])
            if isinstance(note_topics, list):
                topics_counter.update(note_topics)

            # Notes created today
            note_date = post.metadata.get("date", "")
            if note_date == today_str:
                notes_today += 1

        except Exception:
            continue

    orphans = all_stems - linked_targets
    # Daily notes and templates are not really orphans
    orphans = {s for s in orphans if not re.match(r"\d{4}-\d{2}-\d{2}", s)}

    return {
        "total_notes": total,
        "total_links": total_links,
        "orphan_notes": len(orphans),
        "notes_today": notes_today,
        "top_topics": topics_counter.most_common(10),
    }
