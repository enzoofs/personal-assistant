"""LLM-based topic extraction from text content."""

import json
import logging

from atlas.services.openai_client import chat_completion

logger = logging.getLogger(__name__)

TOPIC_PROMPT = """\
Extraia de 3 a 5 tópicos/tags do texto abaixo. Os tópicos devem ser:
- Palavras simples ou compostas curtas (máximo 2 palavras)
- Em português, lowercase
- Relevantes para categorização e busca futura
- Específicos (evite "geral", "informação", "nota")

Retorne APENAS um JSON array de strings. Exemplo: ["python", "automação", "api"]
Sem markdown.\
"""


async def extract_topics(content: str) -> list[str]:
    """Extract topics/tags from content using LLM.

    Args:
        content: Text content to analyze.

    Returns:
        List of topic strings.
    """
    if not content or len(content.strip()) < 20:
        return []

    try:
        raw = await chat_completion(
            messages=[
                {"role": "system", "content": TOPIC_PROMPT},
                {"role": "user", "content": content[:2000]},
            ],
            temperature=0.1,
        )
        topics = json.loads(raw)
        if isinstance(topics, list):
            return [t.strip().lower() for t in topics if isinstance(t, str) and t.strip()]
        return []
    except (json.JSONDecodeError, Exception) as e:
        logger.warning("Topic extraction failed: %s", e)
        return []
