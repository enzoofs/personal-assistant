"""Extract knowledge from conversations and create/update vault notes."""

import json
import logging
import re
from datetime import datetime

from zoneinfo import ZoneInfo

from atlas.config import settings
from atlas.services.openai_client import chat_completion
from atlas.vault.indexer import search_vault
from atlas.vault.linker import auto_link
from atlas.vault.manager import (
    _vault_path,
    append_to_daily_note,
    read_note,
    write_note,
)
from atlas.vault.topic_extractor import extract_topics

logger = logging.getLogger(__name__)

EXTRACTION_PROMPT = """\
Analise a conversa abaixo e extraia conhecimento que vale a pena documentar.

Tipos de conhecimento a extrair:
- Fatos sobre pessoas (quem é, relação, dados de contato)
- Informações sobre projetos (o que é, decisões tomadas, status)
- Pesquisas e aprendizados (conceitos explicados, tutoriais, receitas)
- Insights e reflexões pessoais
- Decisões importantes

NÃO extraia:
- Comandos operacionais ("cria evento", "mostra agenda")
- Saudações e conversa trivial
- Informações muito vagas ou genéricas

Para cada item extraído, retorne:
{{
  "title": "Título conciso da nota (nome próprio ou conceito)",
  "content": "Conteúdo relevante em formato texto corrido",
  "category": "people|projects|research|insights|inbox",
  "tags": ["tag1", "tag2"]
}}

Retorne um JSON array. Se não houver conhecimento relevante, retorne [].
Responda APENAS com JSON válido, sem markdown.\
"""


def _slugify(text: str, max_length: int = 50) -> str:
    text = text[:max_length].lower()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[-\s]+", "-", text).strip("-")
    return text


async def extract_knowledge(conversation: list[dict]) -> list[dict]:
    """Extract knowledge from conversation and create/update vault notes.

    Args:
        conversation: List of message dicts with role and content.

    Returns:
        List of created/updated note info dicts.
    """
    if len(conversation) < 3:
        return []

    conv_text = "\n".join(f"{m['role']}: {m['content']}" for m in conversation[-10:])

    try:
        raw = await chat_completion(
            messages=[
                {"role": "system", "content": EXTRACTION_PROMPT},
                {"role": "user", "content": conv_text},
            ],
            temperature=0.1,
        )
        items = json.loads(raw)
        if not isinstance(items, list):
            return []
    except (json.JSONDecodeError, Exception) as e:
        logger.warning("Knowledge extraction failed: %s", e)
        return []

    results = []
    tz = ZoneInfo(settings.timezone)
    now = datetime.now(tz)
    date_str = now.strftime("%Y-%m-%d")
    time_str = now.strftime("%H:%M")

    for item in items:
        title = item.get("title", "").strip()
        content = item.get("content", "").strip()
        category = item.get("category", "inbox")
        tags = item.get("tags", [])

        if not title or not content:
            continue

        slug = _slugify(title)
        filename = f"{slug}.md"
        note_path = f"{category}/{filename}"

        # Check if note already exists (search vault for similar title)
        existing = search_vault(title, n_results=3)
        existing_match = None
        for e in existing:
            if _slugify(e.get("title", "")) == slug:
                existing_match = e
                break

        if existing_match:
            # Append to existing note
            try:
                fm, old_content = read_note(existing_match["path"])
                updated_content = old_content.rstrip() + f"\n\n## Atualização ({date_str})\n\n{content}"
                updated_content = auto_link(updated_content, exclude_title=title)

                # Update topics
                new_topics = await extract_topics(content)
                existing_topics = fm.get("topics", [])
                merged_topics = list(set(existing_topics + new_topics + tags))
                fm["topics"] = merged_topics
                fm["updated"] = date_str

                write_note(existing_match["path"], fm, updated_content)
                results.append({
                    "path": existing_match["path"],
                    "title": title,
                    "action": "updated",
                })
                logger.info("Updated note: %s", existing_match["path"])
            except Exception:
                logger.exception("Failed to update note: %s", existing_match["path"])
                continue
        else:
            # Create new note
            topics = await extract_topics(content)
            merged_topics = list(set(topics + tags))

            fm = {
                "title": title,
                "date": date_str,
                "category": category,
                "tags": tags,
                "topics": merged_topics,
                "related": [],
                "created_from": "conversation",
            }

            note_content = f"# {title}\n\n{content}"
            note_content = auto_link(note_content, exclude_title=title)

            # Find related notes via semantic search
            related = search_vault(content, n_results=3)
            related_links = []
            for r in related:
                r_title = r.get("title", "")
                if r_title and _slugify(r_title) != slug:
                    related_links.append(f"[[{r_title}]]")

            if related_links:
                fm["related"] = related_links
                note_content += "\n\n## Relacionados\n\n" + "\n".join(f"- {link}" for link in related_links)

            write_note(note_path, fm, note_content)
            results.append({
                "path": note_path,
                "title": title,
                "action": "created",
            })
            logger.info("Created note: %s", note_path)

        # Reference in daily note
        ref = f"- [{time_str}] [[{slug}]] — {title}"
        append_to_daily_note("## Notas", ref)

    return results
