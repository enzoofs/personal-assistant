"""Automatic wikilink detection and insertion for Obsidian notes."""

import logging
import re
from pathlib import Path

from atlas.config import settings

logger = logging.getLogger(__name__)


def get_existing_note_titles() -> dict[str, str]:
    """Get a mapping of lowercase title -> relative path for all vault notes.

    Returns:
        Dict mapping lowercase note title to its relative path.
    """
    vault = Path(settings.vault_path)
    if not vault.exists():
        return {}

    titles = {}
    for md_file in vault.rglob("*.md"):
        if md_file.name.startswith("."):
            continue
        stem = md_file.stem
        rel = str(md_file.relative_to(vault))
        titles[stem.lower()] = rel
    return titles


def auto_link(content: str, exclude_title: str = "") -> str:
    """Insert [[wikilinks]] into content for references to existing notes.

    Scans the content for substrings that match existing note titles
    and wraps them in wikilinks. Avoids double-linking and self-linking.

    Args:
        content: Markdown content to process.
        exclude_title: Title of the current note (to avoid self-links).

    Returns:
        Content with wikilinks inserted.
    """
    titles = get_existing_note_titles()
    if not titles:
        return content

    # Sort by length descending so longer titles match first
    sorted_titles = sorted(titles.keys(), key=len, reverse=True)

    exclude_lower = exclude_title.lower()

    for title_lower in sorted_titles:
        if title_lower == exclude_lower:
            continue
        if len(title_lower) < 3:
            continue

        # Find the original-case version from the stem
        original_stem = Path(titles[title_lower]).stem

        # Don't link inside existing wikilinks or frontmatter
        pattern = re.compile(
            r"(?<!\[\[)"  # not already inside [[
            + re.escape(original_stem)
            + r"(?!\]\])",  # not already followed by ]]
            re.IGNORECASE,
        )

        def _replace(match: re.Match) -> str:
            return f"[[{original_stem}]]"

        # Only replace in content body (skip lines starting with ---)
        lines = content.split("\n")
        in_frontmatter = False
        new_lines = []
        for line in lines:
            if line.strip() == "---":
                in_frontmatter = not in_frontmatter
                new_lines.append(line)
                continue
            if in_frontmatter or line.startswith("#"):
                new_lines.append(line)
                continue
            new_lines.append(pattern.sub(_replace, line, count=1))

        content = "\n".join(new_lines)

    return content


def extract_wikilinks(content: str) -> list[str]:
    """Extract all [[wikilink]] targets from content.

    Args:
        content: Markdown content.

    Returns:
        List of linked note names (without brackets).
    """
    return re.findall(r"\[\[([^\]|]+)(?:\|[^\]]+)?\]\]", content)
