"""Filesystem CRUD operations for markdown notes with YAML frontmatter."""

from datetime import datetime
from pathlib import Path

import frontmatter

from atlas.config import settings
from atlas.vault.templates import daily_note_template

VAULT_FOLDERS = [
    "daily",
    "inbox",
    "projects",
    "people",
    "habits/health",
    "habits/productivity",
    "research",
    "insights",
    "templates",
]


def _vault_path() -> Path:
    return Path(settings.vault_path)


def ensure_vault_structure() -> None:
    """Create all required vault folders if they don't exist."""
    base = _vault_path()
    base.mkdir(parents=True, exist_ok=True)
    for folder in VAULT_FOLDERS:
        (base / folder).mkdir(parents=True, exist_ok=True)


def write_note(path: str, fm: dict, content: str, auto_link_content: bool = False) -> None:
    """Write a markdown note with YAML frontmatter.

    Args:
        path: Relative path within the vault (e.g. "inbox/my-note.md").
        fm: Frontmatter dictionary.
        content: Markdown content body.
        auto_link_content: If True, auto-insert wikilinks before saving.
    """
    if auto_link_content:
        from atlas.vault.linker import auto_link
        title = fm.get("title", Path(path).stem)
        content = auto_link(content, exclude_title=title)

    file_path = _vault_path() / path
    file_path.parent.mkdir(parents=True, exist_ok=True)

    post = frontmatter.Post(content, **fm)
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(frontmatter.dumps(post))


def update_note(path: str, append_content: str) -> None:
    """Append content to an existing note.

    Args:
        path: Relative path within the vault.
        append_content: Content to append.
    """
    fm, content = read_note(path)
    new_content = content.rstrip() + "\n\n" + append_content
    write_note(path, fm, new_content)


def read_note(path: str) -> tuple[dict, str]:
    """Read a markdown note, returning frontmatter and content.

    Args:
        path: Relative path within the vault.

    Returns:
        Tuple of (frontmatter_dict, content_string).

    Raises:
        FileNotFoundError: If the note doesn't exist.
    """
    file_path = _vault_path() / path
    if not file_path.exists():
        raise FileNotFoundError(f"Note not found: {path}")

    post = frontmatter.load(str(file_path))
    return dict(post.metadata), post.content


def list_notes(folder: str) -> list[Path]:
    """List all .md files in a vault folder, sorted by name.

    Args:
        folder: Relative folder path within the vault.

    Returns:
        Sorted list of Path objects for .md files.
    """
    folder_path = _vault_path() / folder
    if not folder_path.exists():
        return []
    return sorted(p for p in folder_path.iterdir() if p.suffix == ".md")


def get_daily_note_path() -> Path:
    """Get the relative path for today's daily note.

    Returns:
        Path like Path("daily/2026-02-02.md").
    """
    date_str = datetime.now().strftime("%Y-%m-%d")
    return Path("daily") / f"{date_str}.md"


def append_to_daily_note(section: str, text: str) -> None:
    """Append text to a section in today's daily note.

    Creates the daily note from template if it doesn't exist.
    Creates the section if it doesn't exist.
    Inserts text at the end of the specified section.

    Args:
        section: Section header (e.g. "## Notas").
        text: Text to append.
    """
    daily_path = get_daily_note_path()
    full_path = _vault_path() / daily_path

    if not full_path.exists():
        date_str = datetime.now().strftime("%Y-%m-%d")
        fm, content = daily_note_template(date_str)
        write_note(str(daily_path), fm, content)

    fm, content = read_note(str(daily_path))
    lines = content.split("\n")

    # Find the section
    section_idx = None
    for i, line in enumerate(lines):
        if line.strip() == section:
            section_idx = i
            break

    if section_idx is None:
        # Section doesn't exist — append at end
        lines.append("")
        lines.append(section)
        lines.append(text)
    else:
        # Find end of section (next ## header or end of file)
        insert_idx = len(lines)
        for i in range(section_idx + 1, len(lines)):
            if lines[i].strip().startswith("## "):
                insert_idx = i
                break

        lines.insert(insert_idx, text)

    new_content = "\n".join(lines)
    write_note(str(daily_path), fm, new_content)
