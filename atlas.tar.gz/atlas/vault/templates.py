"""Templates for markdown notes in the Obsidian vault."""

from datetime import datetime


def daily_note_template(date_str: str) -> tuple[dict, str]:
    """Generate frontmatter and content for a daily note.

    Args:
        date_str: Date in YYYY-MM-DD format.

    Returns:
        Tuple of (frontmatter_dict, content_string).
    """
    frontmatter = {
        "date": date_str,
        "tags": ["daily"],
        "topics": [],
    }

    content = (
        f"# {date_str}\n\n"
        "## Agenda\n\n\n"
        "## Notas\n\n\n"
        "## Hábitos\n\n\n"
        "## Conversas\n\n\n"
        "## Tópicos do Dia\n\n"
    )

    return frontmatter, content


def note_template(title: str, category: str, tags: list[str]) -> tuple[dict, str]:
    """Generate frontmatter and content for a generic note.

    Args:
        title: Note title.
        category: Note category (inbox, projects, people, etc.).
        tags: List of tags.

    Returns:
        Tuple of (frontmatter_dict, content_string).
    """
    date_str = datetime.now().strftime("%Y-%m-%d")

    frontmatter = {
        "date": date_str,
        "title": title,
        "category": category,
        "tags": tags,
        "topics": [],
        "related": [],
        "created_from": "manual",
    }

    content = f"# {title}\n\n"

    return frontmatter, content
